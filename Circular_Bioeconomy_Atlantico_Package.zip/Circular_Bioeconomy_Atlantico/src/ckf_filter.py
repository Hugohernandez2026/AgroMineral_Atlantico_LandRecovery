"""
Cubature Kalman Filter (CKF) for IoT Sensor Data Fusion (Module 4)
=================================================================

Implementation of the Cubature Kalman Filter following:
Arasaratnam, I.; Haykin, S. Cubature Kalman Filters.
IEEE Trans. Autom. Control 2009, 54, 1254–1269.

Manuscript equations 8–20.
"""

from __future__ import annotations
import numpy as np
from typing import Callable, Optional, Tuple


class CubatureKalmanFilter:
    """
    Square-root free Cubature Kalman Filter for non-linear state estimation.

    Parameters
    ----------
    dim_x : int
        Dimension of the state vector.
    dim_z : int
        Dimension of the measurement vector.
    dt : float
        Sampling interval (used only if the process model needs it).
    """

    def __init__(self, dim_x: int, dim_z: int, dt: float = 1.0):
        self.dim_x = dim_x
        self.dim_z = dim_z
        self.dt = dt
        self.n_cubature = 2 * dim_x

        # State mean and covariance
        self.x = np.zeros(dim_x)
        self.P = np.eye(dim_x)

        # Process and measurement noise covariances
        self.Q = np.eye(dim_x) * 0.01
        self.R = np.eye(dim_z) * 0.1

        # Process and measurement functions (to be set by user)
        self.f: Optional[Callable] = None   # x_{k} = f(x_{k-1}, u_{k-1})
        self.h: Optional[Callable] = None   # z_k = h(x_k)

    def _cubature_points(self, x: np.ndarray, P: np.ndarray) -> np.ndarray:
        """Generate 2n cubature points (Eq. 10)."""
        n = self.dim_x
        try:
            S = np.linalg.cholesky(P)
        except np.linalg.LinAlgError:
            # Add jitter if P is not positive definite
            S = np.linalg.cholesky(P + np.eye(n) * 1e-8)

        points = np.zeros((self.n_cubature, n))
        for i in range(n):
            points[i] = x + np.sqrt(n) * S[:, i]
            points[n + i] = x - np.sqrt(n) * S[:, i]
        return points

    def predict(self, u: Optional[np.ndarray] = None):
        """
        Time-update (prediction) step – Eqs. 10–13.
        """
        if self.f is None:
            raise RuntimeError("Process function f has not been set.")

        # Generate cubature points from previous posterior
        chi = self._cubature_points(self.x, self.P)

        # Propagate through process model
        chi_pred = np.zeros_like(chi)
        for i in range(self.n_cubature):
            chi_pred[i] = self.f(chi[i], u)

        # Predicted mean (Eq. 12)
        self.x = np.mean(chi_pred, axis=0)

        # Predicted covariance (Eq. 13)
        P = np.zeros((self.dim_x, self.dim_x))
        for i in range(self.n_cubature):
            dx = chi_pred[i] - self.x
            P += np.outer(dx, dx)
        self.P = P / self.n_cubature + self.Q

        # Store for measurement update
        self._chi_pred = chi_pred

    def update(self, z: np.ndarray):
        """
        Measurement-update (correction) step – Eqs. 14–20.
        """
        if self.h is None:
            raise RuntimeError("Measurement function h has not been set.")

        # Propagate predicted cubature points through measurement model
        Z = np.zeros((self.n_cubature, self.dim_z))
        for i in range(self.n_cubature):
            Z[i] = self.h(self._chi_pred[i])

        # Predicted measurement mean (Eq. 15)
        z_pred = np.mean(Z, axis=0)

        # Innovation covariance (Eq. 16)
        Pzz = np.zeros((self.dim_z, self.dim_z))
        for i in range(self.n_cubature):
            dz = Z[i] - z_pred
            Pzz += np.outer(dz, dz)
        Pzz = Pzz / self.n_cubature + self.R

        # Cross covariance (Eq. 17)
        Pxz = np.zeros((self.dim_x, self.dim_z))
        for i in range(self.n_cubature):
            dx = self._chi_pred[i] - self.x
            dz = Z[i] - z_pred
            Pxz += np.outer(dx, dz)
        Pxz = Pxz / self.n_cubature

        # Kalman gain (Eq. 18)
        K = Pxz @ np.linalg.inv(Pzz)

        # Posterior mean and covariance (Eqs. 19–20)
        self.x = self.x + K @ (z - z_pred)
        self.P = self.P - K @ Pzz @ K.T

    def filter_sequence(
        self,
        measurements: np.ndarray,
        controls: Optional[np.ndarray] = None,
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Run the full filter over a sequence of measurements.

        Parameters
        ----------
        measurements : array, shape (N, dim_z)
        controls : array, shape (N, dim_u) or None

        Returns
        -------
        xs : array, shape (N, dim_x) – filtered state estimates
        Ps : array, shape (N, dim_x, dim_x) – filtered covariances
        """
        N = measurements.shape[0]
        xs = np.zeros((N, self.dim_x))
        Ps = np.zeros((N, self.dim_x, self.dim_x))

        for k in range(N):
            u = None if controls is None else controls[k]
            self.predict(u)
            self.update(measurements[k])
            xs[k] = self.x.copy()
            Ps[k] = self.P.copy()

        return xs, Ps


def example_soil_state_filter():
    """
    Demonstration: filter a 4-dimensional soil state
    [moisture, temperature, EC, pH] from noisy measurements.
    """
    np.random.seed(42)
    dim_x = 4
    dim_z = 4
    N = 500

    # Simple linear process (identity + small drift)
    def f(x, u=None):
        return x + np.array([0.001, -0.002, 0.0, 0.0])

    def h(x):
        return x  # direct measurement

    # True trajectory
    x_true = np.zeros((N, dim_x))
    x_true[0] = [28.0, 27.5, 0.45, 6.2]
    for k in range(1, N):
        x_true[k] = f(x_true[k - 1]) + np.random.randn(dim_x) * 0.05

    # Noisy measurements
    R_true = np.diag([2.5, 1.2, 0.08, 0.15]) ** 2
    z = x_true + np.random.multivariate_normal(np.zeros(dim_z), R_true, size=N)

    # CKF
    ckf = CubatureKalmanFilter(dim_x, dim_z)
    ckf.f = f
    ckf.h = h
    ckf.Q = np.eye(dim_x) * 0.01
    ckf.R = R_true
    ckf.x = z[0].copy()
    ckf.P = np.eye(dim_x) * 5.0

    xs, _ = ckf.filter_sequence(z)

    rmse_raw = np.sqrt(np.mean((z - x_true) ** 2, axis=0))
    rmse_filt = np.sqrt(np.mean((xs - x_true) ** 2, axis=0))

    print("CKF demonstration (soil state estimation)")
    print("Variable          RMSE raw    RMSE filtered")
    labels = ["Moisture (%)", "Temp (°C)", "EC (dS/m)", "pH"]
    for i, lab in enumerate(labels):
        print(f"{lab:16s}  {rmse_raw[i]:8.3f}    {rmse_filt[i]:8.3f}")
    return xs, z, x_true


if __name__ == "__main__":
    example_soil_state_filter()
