"""
Model Predictive Control for Precision Variable-Rate Application (Module 3)
===========================================================================

Finite-horizon quadratic program (manuscript Eqs. 5–7):

  min_u  Σ_{k=0}^{N} ( ‖x_k − x_ref‖_Q² + ‖u_k‖_R² )
  s.t.   x_{k+1} = A x_k + B u_k
         u_min ≤ u_k ≤ u_max
         Δu_min ≤ Δu_k ≤ Δu_max

Horizon N = 10.
"""

from __future__ import annotations
import numpy as np
from scipy.optimize import minimize
from typing import Optional, Tuple


class ModelPredictiveController:
    """
    Linear Model Predictive Controller for multi-input nutrient application.
    """

    def __init__(
        self,
        A: np.ndarray,
        B: np.ndarray,
        Q: np.ndarray,
        R: np.ndarray,
        N: int = 10,
        u_min: Optional[np.ndarray] = None,
        u_max: Optional[np.ndarray] = None,
        du_max: Optional[np.ndarray] = None,
    ):
        self.A = np.atleast_2d(A)
        self.B = np.atleast_2d(B)
        self.Q = np.atleast_2d(Q)
        self.R = np.atleast_2d(R)
        self.N = N

        self.nx = self.A.shape[0]
        self.nu = self.B.shape[1]

        self.u_min = u_min if u_min is not None else np.zeros(self.nu)
        self.u_max = u_max if u_max is not None else np.ones(self.nu) * 100.0
        self.du_max = du_max if du_max is not None else np.ones(self.nu) * 20.0

        self.u_prev = np.zeros(self.nu)

    def _cost(self, u_seq: np.ndarray, x0: np.ndarray, x_ref: np.ndarray) -> float:
        """Evaluate the quadratic cost for a candidate control sequence."""
        u_seq = u_seq.reshape(self.N, self.nu)
        cost = 0.0
        x = x0.copy()
        for k in range(self.N):
            u = u_seq[k]
            err = x - x_ref
            cost += float(err.T @ self.Q @ err + u.T @ self.R @ u)
            x = self.A @ x + self.B @ u
        return cost

    def compute(self, x0: np.ndarray, x_ref: np.ndarray) -> np.ndarray:
        """
        Solve the MPC problem and return the first control action (receding horizon).

        Parameters
        ----------
        x0 : array (nx,)
            Current state estimate (from CKF).
        x_ref : array (nx,)
            Desired reference state.

        Returns
        -------
        u0 : array (nu,)
            Optimal control action for the current instant.
        """
        # Initial guess: repeat previous control
        u0 = np.tile(self.u_prev, self.N)

        # Box constraints on u
        bounds = []
        for _ in range(self.N):
            for i in range(self.nu):
                bounds.append((self.u_min[i], self.u_max[i]))

        res = minimize(
            fun=self._cost,
            x0=u0,
            args=(x0, x_ref),
            method="SLSQP",
            bounds=bounds,
            options={"maxiter": 100, "disp": False},
        )

        u_opt = res.x.reshape(self.N, self.nu)
        u_apply = u_opt[0]

        # Rate constraint (soft)
        du = u_apply - self.u_prev
        du = np.clip(du, -self.du_max, self.du_max)
        u_apply = self.u_prev + du

        self.u_prev = u_apply.copy()
        return u_apply


def default_mpc() -> ModelPredictiveController:
    """
    Factory that returns an MPC configured with the matrices
    used in the Atlántico field trials (identified from incubation experiments).
    """
    # State: [SOC_proxy, available_N, moisture]
    # Input: [compost_rate_kg_ha, liquid_extract_L_ha]
    A = np.array([
        [0.98, 0.01, 0.00],
        [0.02, 0.95, 0.00],
        [0.00, 0.00, 0.92],
    ])
    B = np.array([
        [0.015, 0.005],
        [0.08,  0.04],
        [0.01,  0.02],
    ])
    Q = np.diag([10.0, 5.0, 2.0])
    R = np.diag([0.1, 0.05])

    return ModelPredictiveController(
        A=A, B=B, Q=Q, R=R, N=10,
        u_min=np.array([0.0, 0.0]),
        u_max=np.array([8000.0, 500.0]),   # kg/ha and L/ha
        du_max=np.array([1500.0, 100.0]),
    )


if __name__ == "__main__":
    mpc = default_mpc()
    x0 = np.array([0.7, 12.0, 18.0])       # degraded state
    x_ref = np.array([1.8, 35.0, 25.0])    # target restored state
    u = mpc.compute(x0, x_ref)
    print("MPC first control action (compost kg/ha, extract L/ha):")
    print(u)
