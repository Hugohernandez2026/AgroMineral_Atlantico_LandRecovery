"""
Multivariable PID Controller for Controlled Composting (Module 2)
================================================================

Implements three parallel PID loops for:
  - Bed temperature (T)
  - Moisture content (H)
  - Oxygen concentration (O2)

Equations (manuscript Eqs. 1–4):

  e_T(t) = T_sp - T(t)
  u_T(t) = Kp_T * e_T + Ki_T * ∫e_T dt + Kd_T * de_T/dt

  (analogous for H and O2)

Tuned gains used in the field trials are the default values.
"""

from __future__ import annotations
import numpy as np
from dataclasses import dataclass, field
from typing import Dict, Tuple


@dataclass
class PIDGains:
    Kp: float
    Ki: float
    Kd: float


@dataclass
class PIDState:
    integral: float = 0.0
    prev_error: float = 0.0


class PIDController:
    """Single-loop PID with anti-windup and output saturation."""

    def __init__(
        self,
        gains: PIDGains,
        setpoint: float,
        output_limits: Tuple[float, float] = (0.0, 100.0),
        integral_limits: Tuple[float, float] = (-50.0, 50.0),
        dt: float = 1.0,
    ):
        self.gains = gains
        self.setpoint = setpoint
        self.output_min, self.output_max = output_limits
        self.integral_min, self.integral_max = integral_limits
        self.dt = dt
        self.state = PIDState()

    def update(self, measurement: float) -> float:
        error = self.setpoint - measurement

        # Proportional
        p_term = self.gains.Kp * error

        # Integral with anti-windup
        self.state.integral += error * self.dt
        self.state.integral = np.clip(
            self.state.integral, self.integral_min, self.integral_max
        )
        i_term = self.gains.Ki * self.state.integral

        # Derivative
        d_term = self.gains.Kd * (error - self.state.prev_error) / self.dt
        self.state.prev_error = error

        output = p_term + i_term + d_term
        output = np.clip(output, self.output_min, self.output_max)
        return float(output)

    def reset(self):
        self.state = PIDState()


class MultivariableCompostingPID:
    """
    Three parallel PID controllers for composting process.
    Default gains correspond to the values reported in the manuscript.
    """

    def __init__(self, dt: float = 60.0):  # 60 s sampling
        self.dt = dt

        # Temperature loop (°C) – setpoint 60 °C
        self.pid_T = PIDController(
            gains=PIDGains(Kp=2.4, Ki=0.15, Kd=0.80),
            setpoint=60.0,
            output_limits=(0.0, 100.0),  # % fan speed
            dt=dt,
        )

        # Moisture loop (% wb) – setpoint 55 %
        self.pid_H = PIDController(
            gains=PIDGains(Kp=1.8, Ki=0.10, Kd=0.45),
            setpoint=55.0,
            output_limits=(0.0, 100.0),  # % valve opening
            dt=dt,
        )

        # Oxygen loop (% v/v) – setpoint 15 %
        self.pid_O = PIDController(
            gains=PIDGains(Kp=3.1, Ki=0.22, Kd=0.60),
            setpoint=15.0,
            output_limits=(0.0, 100.0),  # % aeration intensity
            dt=dt,
        )

    def step(
        self, T: float, H: float, O2: float
    ) -> Dict[str, float]:
        """
        Compute control actions for one sampling instant.

        Returns
        -------
        dict with keys: u_T, u_H, u_O, e_T, e_H, e_O
        """
        u_T = self.pid_T.update(T)
        u_H = self.pid_H.update(H)
        u_O = self.pid_O.update(O2)

        return {
            "u_T": u_T,
            "u_H": u_H,
            "u_O": u_O,
            "e_T": self.pid_T.setpoint - T,
            "e_H": self.pid_H.setpoint - H,
            "e_O": self.pid_O.setpoint - O2,
        }

    def reset(self):
        self.pid_T.reset()
        self.pid_H.reset()
        self.pid_O.reset()


def simulate_composting_cycle(
    duration_hours: float = 28 * 24,
    dt_seconds: float = 60.0,
    noise_std: Dict[str, float] | None = None,
) -> Dict[str, np.ndarray]:
    """
    Simple nonlinear simulation of a composting cycle under PID control.
    Used for illustration and unit testing.
    """
    if noise_std is None:
        noise_std = {"T": 0.8, "H": 1.5, "O2": 0.6}

    n_steps = int(duration_hours * 3600 / dt_seconds)
    controller = MultivariableCompostingPID(dt=dt_seconds)

    # Simple process model parameters
    T = 35.0   # initial temperature
    H = 62.0   # initial moisture
    O2 = 18.0  # initial oxygen

    log = {
        "time_h": np.zeros(n_steps),
        "T": np.zeros(n_steps),
        "H": np.zeros(n_steps),
        "O2": np.zeros(n_steps),
        "u_T": np.zeros(n_steps),
        "u_H": np.zeros(n_steps),
        "u_O": np.zeros(n_steps),
    }

    for k in range(n_steps):
        # Measurement noise
        T_m = T + np.random.normal(0, noise_std["T"])
        H_m = H + np.random.normal(0, noise_std["H"])
        O2_m = O2 + np.random.normal(0, noise_std["O2"])

        actions = controller.step(T_m, H_m, O2_m)

        # Simplified process dynamics (first-order + heat generation)
        heat_gen = 0.15 * max(0, 65 - abs(T - 60))  # microbial activity
        T += (0.02 * (actions["u_T"] - 40) + heat_gen - 0.01 * (T - 30)) * (dt_seconds / 3600)
        H += (0.03 * (actions["u_H"] - 30) - 0.008 * actions["u_T"]) * (dt_seconds / 3600)
        O2 += (0.04 * (actions["u_O"] - 20) - 0.02 * heat_gen) * (dt_seconds / 3600)

        # Physical constraints
        T = np.clip(T, 20, 80)
        H = np.clip(H, 20, 80)
        O2 = np.clip(O2, 2, 21)

        log["time_h"][k] = k * dt_seconds / 3600
        log["T"][k] = T
        log["H"][k] = H
        log["O2"][k] = O2
        log["u_T"][k] = actions["u_T"]
        log["u_H"][k] = actions["u_H"]
        log["u_O"][k] = actions["u_O"]

    return log


if __name__ == "__main__":
    print("Running example composting cycle simulation (28 days)...")
    results = simulate_composting_cycle()
    print(f"Final temperature : {results['T'][-1]:.1f} °C")
    print(f"Final moisture    : {results['H'][-1]:.1f} %")
    print(f"Final oxygen      : {results['O2'][-1]:.1f} %")
    print("PID simulation completed successfully.")
