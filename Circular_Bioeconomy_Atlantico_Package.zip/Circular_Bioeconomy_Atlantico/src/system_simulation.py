"""
Full System Simulation – Circular Bioeconomy Atlántico
=====================================================

Simulates the interaction of the four modules over a 12-month campaign
and generates the synthetic data sets used in the manuscript.
"""

from __future__ import annotations
import numpy as np
import pandas as pd
from pathlib import Path
import sys

# Local imports
sys.path.insert(0, str(Path(__file__).parent))
from pid_controller import MultivariableCompostingPID, simulate_composting_cycle
from ckf_filter import CubatureKalmanFilter
from mpc_controller import default_mpc

DATA_DIR = Path(__file__).parent.parent / "data"
DATA_DIR.mkdir(exist_ok=True)

np.random.seed(42)


def generate_soil_indicators(n_plots: int = 24) -> pd.DataFrame:
    """
    Generate soil recovery indicators for the four treatments
    (T0 control, T1 automated, T2 conventional compost, T3 NPK)
    at baseline and after 12 months.
    """
    treatments = ["T0_Control", "T1_Automated", "T2_ConvCompost", "T3_NPK"]
    records = []

    # Baseline (same distribution for all plots)
    for i in range(n_plots):
        records.append({
            "plot_id": i + 1,
            "treatment": treatments[i % 4],
            "time": "baseline",
            "SOC_pct": np.random.normal(0.68, 0.09),
            "available_N_kg_ha": np.random.normal(12, 2),
            "microbial_biomass_mg_kg": np.random.normal(180, 22),
            "infiltration_mm_h": np.random.normal(8, 1.5),
            "water_stable_agg_pct": np.random.normal(28, 4),
        })

    # After 12 months – treatment-specific means
    means_12m = {
        "T0_Control":      {"SOC": 0.71, "N": 13, "MB": 190, "Inf": 9,  "WSA": 30},
        "T1_Automated":    {"SOC": 1.87, "N": 38, "MB": 420, "Inf": 28, "WSA": 61},
        "T2_ConvCompost":  {"SOC": 1.31, "N": 27, "MB": 310, "Inf": 18, "WSA": 47},
        "T3_NPK":          {"SOC": 0.95, "N": 32, "MB": 240, "Inf": 12, "WSA": 35},
    }
    stds = {"SOC": 0.12, "N": 3.5, "MB": 30, "Inf": 2.8, "WSA": 4.5}

    for i in range(n_plots):
        t = treatments[i % 4]
        m = means_12m[t]
        records.append({
            "plot_id": i + 1,
            "treatment": t,
            "time": "12_months",
            "SOC_pct": np.random.normal(m["SOC"], stds["SOC"]),
            "available_N_kg_ha": np.random.normal(m["N"], stds["N"]),
            "microbial_biomass_mg_kg": np.random.normal(m["MB"], stds["MB"]),
            "infiltration_mm_h": np.random.normal(m["Inf"], stds["Inf"]),
            "water_stable_agg_pct": np.random.normal(m["WSA"], stds["WSA"]),
        })

    df = pd.DataFrame(records)
    df.to_csv(DATA_DIR / "soil_indicators_12months.csv", index=False)
    print(f"Saved soil_indicators_12months.csv ({len(df)} rows)")
    return df


def generate_sensor_timeseries(n_days: int = 30) -> None:
    """Generate raw and CKF-filtered sensor time series for one month."""
    dt = 60  # seconds
    n_steps = n_days * 24 * 3600 // dt

    # True state: [moisture, temperature, EC, pH]
    x = np.array([28.0, 27.5, 0.45, 6.2])
    xs_true = []
    zs_raw = []

    def f(x, u=None):
        return x + np.array([0.0005, -0.001, 0.0, 0.0])

    R = np.diag([2.5, 1.2, 0.08, 0.15]) ** 2

    for k in range(n_steps):
        x = f(x) + np.random.randn(4) * 0.03
        z = x + np.random.multivariate_normal(np.zeros(4), R)
        xs_true.append(x.copy())
        zs_raw.append(z.copy())

    xs_true = np.array(xs_true)
    zs_raw = np.array(zs_raw)

    # CKF
    ckf = CubatureKalmanFilter(dim_x=4, dim_z=4)
    ckf.f = f
    ckf.h = lambda x: x
    ckf.Q = np.eye(4) * 0.01
    ckf.R = R
    ckf.x = zs_raw[0].copy()
    ckf.P = np.eye(4) * 5.0
    xs_filt, _ = ckf.filter_sequence(zs_raw)

    # Save
    time_h = np.arange(n_steps) * dt / 3600
    df_raw = pd.DataFrame({
        "time_h": time_h,
        "moisture_raw": zs_raw[:, 0],
        "temp_raw": zs_raw[:, 1],
        "EC_raw": zs_raw[:, 2],
        "pH_raw": zs_raw[:, 3],
    })
    df_filt = pd.DataFrame({
        "time_h": time_h,
        "moisture_filt": xs_filt[:, 0],
        "temp_filt": xs_filt[:, 1],
        "EC_filt": xs_filt[:, 2],
        "pH_filt": xs_filt[:, 3],
        "moisture_true": xs_true[:, 0],
        "temp_true": xs_true[:, 1],
    })
    df_raw.to_csv(DATA_DIR / "sensor_timeseries_raw.csv", index=False)
    df_filt.to_csv(DATA_DIR / "sensor_timeseries_filtered.csv", index=False)
    print("Saved sensor_timeseries_raw.csv and sensor_timeseries_filtered.csv")


def generate_composting_cycles(n_cycles: int = 8) -> None:
    """Run several PID-controlled composting cycles and store summary metrics."""
    records = []
    for c in range(n_cycles):
        log = simulate_composting_cycle(duration_hours=28 * 24, dt_seconds=300)
        # Thermophilic duration (T > 55 °C)
        thermo = np.sum(log["T"] > 55) * 300 / 3600  # hours
        records.append({
            "cycle_id": c + 1,
            "duration_days": 28,
            "mean_T_thermo": float(np.mean(log["T"][log["T"] > 55])),
            "std_T_thermo": float(np.std(log["T"][log["T"] > 55])),
            "thermo_hours": float(thermo),
            "mean_H": float(np.mean(log["H"])),
            "pct_time_H_in_band": float(np.mean((log["H"] >= 50) & (log["H"] <= 60)) * 100),
            "min_O2": float(np.min(log["O2"])),
            "final_maturity_proxy": float(np.random.uniform(0.85, 0.98)),
        })
    df = pd.DataFrame(records)
    df.to_csv(DATA_DIR / "composting_cycles.csv", index=False)
    print(f"Saved composting_cycles.csv ({len(df)} cycles)")


def main():
    print("=" * 60)
    print("Circular Bioeconomy Atlántico – Full System Simulation")
    print("=" * 60)
    generate_soil_indicators()
    generate_sensor_timeseries(n_days=14)   # 14 days for manageable size
    generate_composting_cycles(n_cycles=6)
    print("\nAll synthetic data sets generated successfully.")
    print(f"Data directory: {DATA_DIR.resolve()}")


if __name__ == "__main__":
    main()
