# Data Dictionary  
## Circular Bioeconomy Atlántico – Research Package v1.0.0

All data sets are **simulated** for methodological illustration and full reproducibility.  
They must be replaced by real experimental measurements before formal submission.

---

## 1. soil_indicators_12months.csv

| Column | Type | Unit | Description |
|--------|------|------|-------------|
| plot_id | int | – | Experimental plot identifier (1–24) |
| treatment | str | – | T0_Control, T1_Automated, T2_ConvCompost, T3_NPK |
| time | str | – | "baseline" or "12_months" |
| SOC_pct | float | % | Soil organic carbon (Walkley–Black) |
| available_N_kg_ha | float | kg ha⁻¹ | Available nitrogen (KCl extraction + Kjeldahl) |
| microbial_biomass_mg_kg | float | mg kg⁻¹ | Microbial biomass carbon (chloroform fumigation) |
| infiltration_mm_h | float | mm h⁻¹ | Infiltration rate (double-ring infiltrometer) |
| water_stable_agg_pct | float | % | Water-stable aggregates (wet sieving) |

---

## 2. sensor_timeseries_raw.csv

| Column | Type | Unit | Description |
|--------|------|------|-------------|
| time_h | float | h | Time since start of recording |
| moisture_raw | float | % vol | Volumetric water content (raw sensor) |
| temp_raw | float | °C | Soil temperature (raw sensor) |
| EC_raw | float | dS m⁻¹ | Electrical conductivity (raw) |
| pH_raw | float | – | Soil pH (raw) |

---

## 3. sensor_timeseries_filtered.csv

| Column | Type | Unit | Description |
|--------|------|------|-------------|
| time_h | float | h | Time since start of recording |
| moisture_filt | float | % vol | CKF-filtered volumetric water content |
| temp_filt | float | °C | CKF-filtered soil temperature |
| EC_filt | float | dS m⁻¹ | CKF-filtered electrical conductivity |
| pH_filt | float | – | CKF-filtered soil pH |
| moisture_true | float | % vol | Simulated true moisture (for RMSE evaluation) |
| temp_true | float | °C | Simulated true temperature (for RMSE evaluation) |

---

## 4. composting_cycles.csv

| Column | Type | Unit | Description |
|--------|------|------|-------------|
| cycle_id | int | – | Composting cycle number |
| duration_days | int | d | Total cycle length |
| mean_T_thermo | float | °C | Mean temperature during thermophilic phase (T > 55 °C) |
| std_T_thermo | float | °C | Standard deviation of thermophilic temperature |
| thermo_hours | float | h | Duration of thermophilic phase |
| mean_H | float | % wb | Mean moisture content |
| pct_time_H_in_band | float | % | Percentage of time moisture stayed inside 50–60 % band |
| min_O2 | float | % v/v | Minimum oxygen concentration recorded |
| final_maturity_proxy | float | – | Proxy maturity index (0–1) |

---

## Controlled Variables & Set-points (Module 2)

| Variable | Symbol | Set-point | Band | Actuator |
|----------|--------|-----------|------|----------|
| Bed temperature | T | 60 °C | 55–65 °C | Aeration fan |
| Moisture | H | 55 % wb | 50–60 % | Water valve |
| Oxygen | O₂ | 15 % v/v | > 10 % | Aeration intensity |

## PID Gains (default)

| Loop | Kp | Ki | Kd |
|------|----|----|----|
| Temperature | 2.4 | 0.15 | 0.80 |
| Moisture | 1.8 | 0.10 | 0.45 |
| Oxygen | 3.1 | 0.22 | 0.60 |

## MPC Parameters (Module 3)

- Prediction horizon N = 10
- State vector: [SOC_proxy, available_N, moisture]
- Control vector: [compost_rate (kg ha⁻¹), liquid_extract (L ha⁻¹)]
- Matrices A, B, Q, R: see `src/mpc_controller.py` → `default_mpc()`
