# System Architecture – Circular Bioeconomy Atlántico

## High-Level Overview

```
┌─────────────────┐    ┌──────────────────────┐    ┌─────────────────────┐
│  Module 1       │    │  Module 2            │    │  Module 3           │
│  Waste Sorting  │───▶│  Controlled Compost  │───▶│  Precision Apply    │
│  (Vision+NIR)   │    │  (Multivariable PID) │    │  (MPC)              │
└─────────────────┘    └──────────┬───────────┘    └──────────┬──────────┘
                                  │                           │
                                  └────────────┬──────────────┘
                                               ▼
                                  ┌──────────────────────┐
                                  │  Module 4            │
                                  │  IoT + CKF Fusion    │
                                  │  (State Estimation)  │
                                  └──────────────────────┘
```

## Data & Control Flows

- **Material flow**: Organic waste → Sorted fractions → Compost reactors → Variable-rate spreader → Soil
- **Information flow**: Sensors → CKF → PID set-points & MPC state observer → Actuators
- **Communication**: MQTT over local Wi-Fi / LoRaWAN edge network

## Edge Hardware (reference implementation)

- Single-board computer (Raspberry Pi 4 or equivalent)
- Python 3.10+ runtime
- Real-time sampling: 60 s (PID & CKF), 30 s (MPC)

## Reproducibility

All algorithms, gains, matrices and noise covariances are hard-coded in the `src/` modules with the exact values reported in the manuscript.  
Running `python src/system_simulation.py` regenerates every CSV used in the analysis pipeline.
