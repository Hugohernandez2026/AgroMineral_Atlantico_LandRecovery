# Complementary Circular Bioeconomy Pathways with Automated Control Systems  
## Recovery of Degraded Lands in Atlántico, Colombia

**Research Article Package** for *ACS Agricultural Science & Technology*

**Authors**  
- Hugo Gaspar Hernández Palma* (Corresponding author)  
  Faculty of Engineering, Corporación Universitaria Iberoamericana, Bogotá, Colombia  
  ORCID: 0000-0002-3873-0530 | hugo.hernandez@docente.ibero.edu.co  

- Anderson Isaías Nieto Granados  
  Faculty of Engineering, Corporación Universitaria Iberoamericana, Bogotá, Colombia  
  ORCID: 0009-0002-2695-3451 | anderson.nieto@docente.ibero.edu.co  

---

## Overview

This repository contains the complete, reproducible research package accompanying the manuscript:

> **Vías Complementarias de Bioeconomía Circular que Integran Sistemas de Control Automatizado para la Recuperación de Tierras Degradadas en Atlántico, Colombia**

The work designs, implements and evaluates four integrated automated modules that convert local organic waste streams into biofertilizers and soil amendments for the recovery of degraded lands in the department of Atlántico, Colombia.

### System Modules

| Module | Description | Control Algorithm |
|--------|-------------|-------------------|
| 1 | Automated organic waste collection & sorting | Computer vision + NIR classification |
| 2 | Controlled composting | Multivariable PID (Temperature, Moisture, O₂) |
| 3 | Precision variable-rate application | Model Predictive Control (MPC) |
| 4 | IoT monitoring platform | Cubature Kalman Filter (CKF) data fusion |

---

## Repository Structure

```
Circular_Bioeconomy_Atlantico/
├── README.md                 # This file
├── CITATION.cff              # Citation metadata
├── LICENSE                   # MIT License
├── requirements.txt          # Python dependencies
├── data/
│   ├── data_dictionary.md    # Full variable descriptions
│   ├── soil_indicators_12months.csv
│   ├── sensor_timeseries_raw.csv
│   ├── sensor_timeseries_filtered.csv
│   ├── composting_cycles.csv
│   └── application_maps.csv
├── src/
│   ├── pid_controller.py     # Multivariable PID implementation
│   ├── mpc_controller.py     # Model Predictive Control
│   ├── ckf_filter.py         # Cubature Kalman Filter
│   ├── system_simulation.py  # Full system simulator
│   └── analysis_pipeline.py  # Statistical analysis & figures
├── docs/
│   └── system_architecture.md
├── manuscript/
│   └── ACS_Bioeconomia_Circular_Atlantico_ES.docx
├── figures/                  # Generated figures (PNG)
└── tests/                    # Unit tests
```

---

## Quick Start

### 1. Environment Setup

```bash
python -m venv venv
source venv/bin/activate          # Linux/macOS
# or
venv\Scripts\activate             # Windows

pip install -r requirements.txt
```

### 2. Reproduce Main Results

```bash
# Run full simulation pipeline
python src/system_simulation.py

# Generate statistical analysis and tables
python src/analysis_pipeline.py
```

### 3. Key Outputs

- Soil recovery indicators (Table 1 of the manuscript)
- PID control performance metrics
- CKF filtering RMSE comparison (raw vs filtered)
- MPC resource-efficiency gains (18–22 % reduction in compost mass)

---

## Control Algorithms (Summary)

### Multivariable PID (Module 2)

```
e_T(t) = T_sp − T(t)
u_T(t) = Kp_T·e_T + Ki_T·∫e_T + Kd_T·de_T/dt
```

Analogous laws for moisture (H) and oxygen (O₂).  
Tuned gains are provided in `src/pid_controller.py`.

### Model Predictive Control (Module 3)

```
min_u  Σ (‖x_k − x_ref‖_Q² + ‖u_k‖_R²)
s.t.   x_{k+1} = A x_k + B u_k
       u_min ≤ u_k ≤ u_max
```

Horizon N = 10. Matrices A, B, Q, R are in `src/mpc_controller.py`.

### Cubature Kalman Filter (Module 4)

Full 2n-cubature-point implementation (Arasaratnam & Haykin, 2009).  
See `src/ckf_filter.py` for the complete prediction–correction cycle (Eqs. 8–20 of the manuscript).

---

## Data Notes

All numerical results presented in the manuscript and in this repository are **simulated** for methodological illustration and reproducibility demonstration.  
They must be replaced by real experimental data before formal journal submission.

---

## Citation

If you use this package, please cite:

```bibtex
@article{HernandezPalma2026,
  title   = {Complementary Circular Bioeconomy Pathways Integrating Automated Control Systems for the Recovery of Degraded Lands in Atlántico, Colombia},
  author  = {Hernández Palma, Hugo Gaspar and Nieto Granados, Anderson Isaías},
  journal = {ACS Agricultural Science \& Technology},
  year    = {2026},
  note    = {Manuscript in preparation}
}
```

---

## License

MIT License – see `LICENSE` file.

## Funding

Internal research funds of the **Corporación Universitaria Iberoamericana**, Bogotá, Colombia.

## Contact

Hugo Gaspar Hernández Palma  
hugo.hernandez@docente.ibero.edu.co  
ORCID: https://orcid.org/0000-0002-3873-0530
