# From Waste to Fertile Land  
## Complementary Circular Bioeconomy Pathways Based on Silicate Rock Dust for the Recovery of Degraded Soils in Atlántico, Colombia

**Research Article Package** for *ACS Agricultural Science & Technology*

**Authors**  
- **Hugo Gaspar Hernández Palma*** (Corresponding author)  
  Faculty of Engineering, Corporación Universitaria Iberoamericana, Bogotá, Colombia  
  ORCID: 0000-0002-3873-0530 | hugo.hernandez@docente.ibero.edu.co  

- **Anderson Isaías Nieto Granados**  
  Faculty of Engineering, Corporación Universitaria Iberoamericana, Bogotá, Colombia  
  ORCID: 0009-0002-2695-3451 | anderson.nieto@docente.ibero.edu.co  

---

## Overview

This repository contains the complete, reproducible research package accompanying the manuscript:

> **From Waste to Fertile Land: Complementary Circular Bioeconomy Pathways Based on Silicate Rock Dust for the Recovery of Degraded Soils in Atlántico, Colombia**

The study develops a multivariate decision framework (Principal Component Analysis + K-means clustering + multiple linear regression) based on X-ray diffraction (XRD) mineral phase data. The framework classifies silicate rock dusts according to their agronomic potential as soil remineralizers and supports circular bioeconomy pathways aimed at restoring degraded lands in the department of Atlántico, Colombia.

### Key Results

| Analysis              | Main Finding                                                                 |
|-----------------------|-----------------------------------------------------------------------------|
| PCA                   | First two components explain **54.4 %** of total variance                   |
| K-means (k = 3)       | Clear separation into **Premium / Standard / Discard** classes              |
| Multiple Regression   | Particle size (mesh) is the dominant predictor of relative solubility (**Adjusted R² = 0.982**) |
| Decision Rule         | Only Premium-class materials with mesh ≥ 200 are recommended for agricultural use |

---

## Repository Structure

```
AgroMineral_Atlantico_LandRecovery/
├── README.md                          # This file
├── CITATION.cff                       # Citation metadata
├── LICENSE                            # MIT License
├── requirements.txt                   # Python dependencies
├── data/
│   ├── data_dictionary.md             # Full variable descriptions
│   ├── agrominerals_drx_master.csv    # 2000 samples (main dataset)
│   ├── datos_remineralizacion_roca.csv# 1000 samples (solubility set)
│   └── agrominerals_drx_dataset_2000_samples.xlsx
├── src/
│   └── 05_pipeline.py                 # Full reproducible analysis pipeline
├── manuscript/
│   └── ACS_Articulo2_Agromineral_Atlantico_ES.docx
├── docs/
│   └── methods_summary.md
├── figures/                           # Generated figures (PNG)
└── tests/
```

---

## Quick Start

### 1. Environment Setup

```bash
python -m venv venv
source venv/bin/activate          # Linux / macOS
# or
venv\Scripts\activate             # Windows

pip install -r requirements.txt
```

### 2. Reproduce Main Results

```bash
python src/05_pipeline.py
```

This command regenerates the principal component analysis, K-means clustering, and regression summaries reported in the manuscript.

---

## Data Description

- **agrominerals_drx_master.csv** (2,000 samples)  
  Mineral phases (quartz, micas, plagioclase, mafics, other minerals), major oxides (SiO₂, K₂O, CaO, MgO, P₂O₅), Mineral Quality Index (ICM), pre-computed PC scores, and mesh size.

- **datos_remineralizacion_roca.csv** (1,000 samples)  
  Independent set used for the multiple linear regression of relative solubility.

A complete data dictionary is available in `data/data_dictionary.md`.

---

## Methods Summary

1. **Principal Component Analysis (PCA)**  
   Performed on the five mineral-phase variables after column-wise standardization. The first two components capture 54.4 % of the variance.

2. **K-means Clustering**  
   Three clusters were retained (elbow + silhouette criteria) and labeled Premium, Standard, and Discard according to mean ICM values.

3. **Multiple Linear Regression**  
   Relative solubility was modeled as a function of major oxides and mesh size. Particle size emerged as the dominant predictor (Adjusted R² = 0.982).

4. **Decision Rule**  
   Only samples classified as **Premium** and meeting a minimum mesh requirement (≤ 200 or finer) are recommended for application on degraded soils in Atlántico.

---

## Citation

If you use this package, please cite:

```bibtex
@article{HernandezPalma2026Atlantico,
  title   = {From Waste to Fertile Land: Complementary Circular Bioeconomy Pathways Based on Silicate Rock Dust for the Recovery of Degraded Soils in Atlántico, Colombia},
  author  = {Hernández Palma, Hugo Gaspar and Nieto Granados, Anderson Isaías},
  journal = {ACS Agricultural Science \& Technology},
  year    = {2026},
  note    = {Manuscript in preparation}
}
```

You can also use the `CITATION.cff` file included in this repository.

---

## License

This project is released under the MIT License. See the `LICENSE` file for details.

## Funding

This research was supported by internal research funds of the **Corporación Universitaria Iberoamericana**, Bogotá, Colombia.

## Contact

**Hugo Gaspar Hernández Palma**  
Corresponding Author  
hugo.hernandez@docente.ibero.edu.co  
ORCID: https://orcid.org/0000-0002-3873-0530  

Faculty of Engineering  
Corporación Universitaria Iberoamericana  
Bogotá, Colombia
