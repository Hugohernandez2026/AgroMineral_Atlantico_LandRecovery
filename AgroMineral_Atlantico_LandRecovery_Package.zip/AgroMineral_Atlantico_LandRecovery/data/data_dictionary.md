# Data Dictionary  
## AgroMineral Atlántico – Land Recovery Package v1.0.0

---

## 1. agrominerals_drx_master.csv (n = 2000)

Main dataset used for PCA and K-means clustering.

| Column | Type | Unit | Description |
|--------|------|------|-------------|
| sample_id | str/int | – | Unique sample identifier |
| data_origin | str | – | experimental / synthetic |
| mesh | int | – | Particle size class (100, 200, 325) |
| mesh_325 | int | – | Binary indicator for mesh 325 |
| quartz_pct | float | % | Quartz mass percentage (XRD Rietveld) |
| micas_pct | float | % | Micas mass percentage |
| plagioclase_pct | float | % | Plagioclase mass percentage |
| mafics_pct | float | % | Mafic minerals mass percentage |
| other_minerals_pct | float | % | Other minerals mass percentage |
| SiO2_pct | float | % | Silicon dioxide (XRF) |
| K2O_pct | float | % | Potassium oxide |
| CaO_pct | float | % | Calcium oxide |
| MgO_pct | float | % | Magnesium oxide |
| P2O5_pct | float | % | Phosphorus pentoxide |
| K_solubility_index | float | – | Potassium solubility index |
| PC1_score | float | – | Pre-computed Principal Component 1 score |
| PC2_score | float | – | Pre-computed Principal Component 2 score |
| ICM_index | float | – | Mineral Quality Index (composite) |

**Note:** The five mineral phases (quartz + micas + plagioclase + mafics + other) sum to 100 % for every sample.

---

## 2. datos_remineralizacion_roca.csv (n = 1000)

Independent dataset used for multiple linear regression of relative solubility.

| Column | Type | Description |
|--------|------|-------------|
| (varies) | – | Contains major oxides, mesh, petrographic class and relative solubility measured under standardized citric-acid extraction. |

---

## Derived Variables & Models

- **ICM_index**: Composite Mineral Quality Index used to rank agronomic potential.
- **PCA**: Performed on the five mineral-phase variables after standardization.
- **K-means**: k = 3 → labels Premium / Standard / Discard.
- **Regression target**: Relative solubility (S).
- **Key predictor**: mesh (particle size).
