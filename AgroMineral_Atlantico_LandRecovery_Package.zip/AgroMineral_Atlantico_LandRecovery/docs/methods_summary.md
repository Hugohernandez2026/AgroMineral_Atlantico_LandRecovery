# Methods Summary – AgroMineral Atlántico Land Recovery

## Principal Component Analysis
- Input: 5 mineral phases (quartz, micas, plagioclase, mafics, other)
- Standardization: zero mean, unit variance
- First two components explain 54.4 % of total variance

## K-means Clustering
- k = 3
- Labels assigned by mean ICM ranking: Premium > Standard > Discard
- Silhouette score used for validation

## Multiple Linear Regression
- Target: Relative solubility
- Dominant predictor: mesh (particle size)
- Adjusted R² ≈ 0.982

## Decision Rule
Only samples classified as **Premium** and with mesh ≥ 200 are recommended for application on degraded soils in Atlántico.
