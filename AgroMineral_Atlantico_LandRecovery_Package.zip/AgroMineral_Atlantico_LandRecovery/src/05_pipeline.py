"""
Full reproducible analysis pipeline
===================================
AgroMineral Atlántico – Land Recovery
PCA + K-means + Multiple Regression

This script regenerates the main numerical results reported in the manuscript.
"""

from __future__ import annotations
import numpy as np
import pandas as pd
from pathlib import Path
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
import statsmodels.api as sm
import warnings
warnings.filterwarnings("ignore")

# Paths
ROOT = Path(__file__).parent.parent
DATA_DIR = ROOT / "data"
FIG_DIR = ROOT / "figures"
FIG_DIR.mkdir(exist_ok=True)

np.random.seed(42)


def load_data():
    master_path = DATA_DIR / "agrominerals_drx_master.csv"
    if not master_path.exists():
        # Fallback to original attachment location
        master_path = Path("/home/workdir/attachments/agrominerals_drx_master.csv")
    df = pd.read_csv(master_path)
    print(f"Loaded master dataset: {df.shape[0]} samples, {df.shape[1]} variables")
    return df


def run_pca(df: pd.DataFrame):
    phases = ["quartz_pct", "micas_pct", "plagioclase_pct", "mafics_pct", "other_minerals_pct"]
    X = df[phases].values
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    pca = PCA(n_components=5, random_state=42)
    scores = pca.fit_transform(X_scaled)

    print("\n" + "="*60)
    print("PCA RESULTS")
    print("="*60)
    for i, (ev, var) in enumerate(zip(pca.explained_variance_, pca.explained_variance_ratio_)):
        print(f"PC{i+1}: eigenvalue = {ev:.3f}  |  variance = {var*100:.2f} %  |  cumulative = {pca.explained_variance_ratio_[:i+1].sum()*100:.2f} %")

    print("\nLoadings (PC1–PC4):")
    loadings = pd.DataFrame(
        pca.components_[:4].T,
        index=phases,
        columns=[f"PC{i+1}" for i in range(4)]
    )
    print(loadings.round(3))
    return pca, scores, scaler


def run_kmeans(scores: np.ndarray, df: pd.DataFrame):
    # Use first 2 PCs + original scaled phases for clustering stability
    kmeans = KMeans(n_clusters=3, random_state=42, n_init=20)
    labels = kmeans.fit_predict(scores[:, :2])

    sil = silhouette_score(scores[:, :2], labels)
    print("\n" + "="*60)
    print("K-MEANS CLUSTERING (k=3)")
    print("="*60)
    print(f"Silhouette score: {sil:.3f}")

    df = df.copy()
    df["cluster"] = labels

    # Map clusters to agronomic labels by mean ICM
    cluster_icm = df.groupby("cluster")["ICM_index"].mean().sort_values(ascending=False)
    mapping = {}
    labels_order = ["Premium", "Standard", "Discard"]
    for i, (cl, _) in enumerate(cluster_icm.items()):
        mapping[cl] = labels_order[i]
    df["cluster_label"] = df["cluster"].map(mapping)

    print("\nCluster sizes and mean ICM:")
    summary = df.groupby("cluster_label").agg(
        n=("ICM_index", "count"),
        mean_ICM=("ICM_index", "mean"),
        mean_quartz=("quartz_pct", "mean"),
        mean_mafics=("mafics_pct", "mean"),
    ).round(2)
    print(summary)
    return df


def run_regression():
    """Attempt to load solubility dataset and fit the model."""
    sol_path = DATA_DIR / "datos_remineralizacion_roca.csv"
    if not sol_path.exists():
        sol_path = Path("/home/workdir/attachments/datos_remineralizacion_roca.csv")
    if not sol_path.exists():
        print("\nSolubility dataset not found – skipping regression.")
        return None

    df_sol = pd.read_csv(sol_path)
    print(f"\nLoaded solubility dataset: {df_sol.shape}")

    # Flexible column detection
    possible_targets = [c for c in df_sol.columns if "solub" in c.lower() or "Solub" in c]
    possible_mesh = [c for c in df_sol.columns if "mesh" in c.lower() or "Mesh" in c or "malla" in c.lower()]

    if not possible_targets:
        print("Could not identify solubility column – skipping regression.")
        return None

    target = possible_targets[0]
    print(f"Using target: {target}")

    # Simple model if mesh is available
    if possible_mesh:
        mesh_col = possible_mesh[0]
        X = sm.add_constant(df_sol[[mesh_col]].astype(float))
        y = df_sol[target].astype(float)
        model = sm.OLS(y, X).fit()
        print("\n" + "="*60)
        print("REGRESSION SUMMARY (simplified – mesh only)")
        print("="*60)
        print(model.summary().tables[1])
        print(f"\nAdjusted R² = {model.rsquared_adj:.4f}")
    return None


def main():
    print("AgroMineral Atlántico – Land Recovery Pipeline")
    print("="*60)
    df = load_data()
    pca, scores, scaler = run_pca(df)
    df_clustered = run_kmeans(scores, df)
    run_regression()

    # Save clustered data
    out_path = DATA_DIR / "master_with_clusters.csv"
    df_clustered.to_csv(out_path, index=False)
    print(f"\nSaved clustered dataset → {out_path}")
    print("\nPipeline completed successfully.")


if __name__ == "__main__":
    main()
